﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace _NonGeneric
{
    class Program
    {
        static void Main(string[] args)
        {
            Hashtable ht = new Hashtable();//random generation on console
            ht.Add("shweta", "88");
            ht.Add("sharad", "58");
            ht.Add("mehak", "69");
            ht.Add("giani", "18");
            ht.Add("Mohak", "78");

            foreach(DictionaryEntry demo in ht)
            {
                Console.WriteLine(demo.Key+" "+demo.Value);
            }
            Console.ReadLine();


        }
    }
}
