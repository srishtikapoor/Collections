﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NonGeneric
{
    class Program
    {
        static void Main(string[] args)
        {
            ArrayList al = new ArrayList();//store values of different data types
            al.Add("string");
            al.Add("srishti");
            int x = 3;
            al.Add(x);

            string name = "Aman";
            al.Add(name);
            foreach(object obj in al)
            {
                Console.WriteLine(obj);
            }
            Console.ReadLine();
        }
    }
}
