﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {
            List<int> AgeOfBrothers = new List<int>();
            AgeOfBrothers.Add(21);
            AgeOfBrothers.Add(35);
            AgeOfBrothers.Add(19);
            AgeOfBrothers.Add(31);

            foreach(int item in AgeOfBrothers)
            {
                Console.WriteLine(item);
            }
            Console.ReadLine();

        }
    }
}
